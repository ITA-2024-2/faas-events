const jwt = require('jsonwebtoken');

// Your secret key
const secretKey = 'your_secret_key';

// Payload for the token
const payload = {
  sub: '1234567890', // Subject (user ID)
  name: 'John Doe',  // Any other data you want to include
  admin: true        // Custom claims
};

// Options (optional)
const options = {
  expiresIn: '1h' // Token expiration time
};

// Generate the token
const token = jwt.sign(payload, secretKey, options);

console.log('Generated JWT Token:', token);
